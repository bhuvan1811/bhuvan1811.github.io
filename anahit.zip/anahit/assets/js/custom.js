// Faqs Dropdown
$(document).ready(function() {
    $('.faqsQuestion').on('click', function() {
        if ($(this).parents('.faqsLists').hasClass('activeFaq')) {
            $(this).parents('.faqsLists').removeClass('activeFaq');
            $(this).parents('.faqsLists').find('.faqsAnswer').slideUp();
            $(this).find('.faqsToggle i').removeClass('fa-chevron-up').addClass('fa-chevron-down');
        } else {
            $('.faqsQuestion').parents('.faqsLists').removeClass('activeFaq');
            $('.faqsQuestion').parents('.faqsLists').find('.faqsAnswer').slideUp();
            $('.faqsQuestion').find('.faqsToggle i').removeClass('fa-chevron-up').addClass('fa-chevron-down');
            $(this).parents('.faqsLists').addClass('activeFaq');
            $(this).parents('.faqsLists').find('.faqsAnswer').slideDown();
            $(this).find('.faqsToggle i').removeClass('fa-chevron-down').addClass('fa-chevron-up');
        }
    });
});

// Member Slider Start
$(document).ready(function() {
    $('.teamSlider').slick({
        autoplay: false,
        autoplaySpeed: 2000,
        arrows: true,
        dots: false,
        slidesToShow: 3,
        infinite: true,
        prevArrow: $(".memberArrLBtn"),
        nextArrow: $(".memberArrRBtn"),
        responsive: [{
                breakpoint: 1337,
                settings: {
                    slidesToShow: 2,
                },
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    centerMode: true,
                },
            },
            // {
            //     breakpoint: 992,
            //     settings: {
            //         slidesToShow: 3,
            //     },
            // },
        ],
    });
});